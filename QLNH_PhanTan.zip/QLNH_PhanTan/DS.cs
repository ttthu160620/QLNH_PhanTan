﻿namespace QLNH_PhanTan
{


    public partial class DS
    {
        partial class Get_SubscribesDataTable
        {
        }

        partial class SP_SAOKEGIAODICHDataTable
        {
        }
    }
}

namespace QLNH_PhanTan.DSTableAdapters
{
    partial class SP_SAOKEGIAODICHTableAdapter
    {
    }

    public partial class SP_DSTAIKHOANTableAdapter {
    }
}
